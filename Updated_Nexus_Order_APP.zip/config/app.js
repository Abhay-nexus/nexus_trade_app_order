const DB_URI = process.env.DB_URI || "mongodb://localhost:27017/nexus_trade";

module.exports = { DB_URI };
